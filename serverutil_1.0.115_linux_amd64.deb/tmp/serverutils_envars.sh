#!/bin/bash

# Guarda la primera IP privada hallada
# de tipo (10.x.x.x, 172.16.x.x - 172.31.x.x, 192.168.x.x)
IP=$(hostname -I | tr ' ' '\n' | grep -E '^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.)' | head -n 1)

CONF_FILE="/etc/asterisk/manager.conf"

if [ ! -f "$CONF_FILE" ]; then
    echo "Aviso: no se encuentra $CONF_FILE (AMI sin configurar)" >&2
fi

# Extraer el primer usuario distinto de [general]
AMI_USER=$(grep -E '^\s*\[.+\]' "$CONF_FILE" 2>/dev/null | grep -v '\[general\]' | head -n 1 | tr -d '[] ')

# Extraer la contraseña asociada a ese contexto o la primera que encuentre
AMI_SECRET=$(grep -E '^\s*secret\s*=' "$CONF_FILE" 2>/dev/null | head -n 1 | cut -d'=' -f2 | tr -d ' ')

if [ -z "$AMI_USER" ] || [ -z "$AMI_SECRET" ]; then
    echo "Aviso: no se pudo extraer usuario/secret AMI de $CONF_FILE" >&2
fi

export SERVERUTILS_DB_HOST="${IP}" 


export SERVERUTILS_DB_USER="${SERVERUTILS_DB_USER:-db_username}"
export SERVERUTILS_DB_PASSWORD="${SERVERUTILS_DB_PASSWORD:-db_password}"
export QRZ_USER="${QRZ_USER:-qrz_user}"
export QRZ_PASSWORD="${QRZ_PASSWORD:-qrz_pass}"
export EMAIL_AYUDA_TO="${EMAIL_AYUDA_TO:-email_ayuda}"
export RESEND_API_KEY="${RESEND_API_KEY:-api_key_resend}"
export ACTIVATION_URL="${ACTIVATION_URL:-https://url-que-activa-el-email}"

# Usuario AMI de manager.conf (permiso originate) para listen-live
export AMI_USER="$AMI_USER"
export LISTENLIVE_PORT="${LISTENLIVE_PORT:-8086}"
export AMI_SECRET="$AMI_SECRET"
